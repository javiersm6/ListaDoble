/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package collection;

/**
 *
 * @author Javier
 */
public class Lista2 {
    
    private Nodo2 cabeza;
    private Nodo2 ultimo;
    private int size;

    public Nodo2 getCabeza() {
        return cabeza;
    }

    public Nodo2 getUltimo() {
        return ultimo;
    }

    public int getSize() {
        return size;
    }
    
    
    
    public Lista2() {
        this.cabeza = null;
        this.ultimo = null;
        this.size = 0;
    }
    
    public int get(int index) {
        if (0 == size) {
            return -1;
        } else if (index > size) {
            throw new IndexOutOfBoundsException();
        } else if (index == 0){
            return cabeza.getDato();
        } else if (index == size) {
            return ultimo.getDato();
        } else {
            Nodo2 aux = cabeza;
            int cont = 0;
            
            while (aux.getSig() != null && cont < index) {
                aux = aux.getSig();
                ++cont;
            }
            
            return aux.getDato();
        }
    }
    
    public int size() {
    int cont = 0;
    for (Nodo2 node = cabeza; node != null; node = node.getSig())
        cont++;
    return cont;
}
    
    public boolean addFirst(int data) {
        Nodo2 nuevo = new Nodo2(data);
        if(cabeza == null){
            cabeza = nuevo;
            ultimo = nuevo;
            size++;
            return true;
        }else{
            nuevo.setSig(cabeza);
            cabeza.setAnt(nuevo);
            cabeza=nuevo;
            size++;
            return true;
        }
       
            
    }
    
    public boolean add(int data){
        if (0 == size) {
            Nodo2 nuevo = new Nodo2(data);
            cabeza = nuevo;
            ultimo = nuevo;
            ++size;
            return true;
        } else {
            Nodo2 nuevo = new Nodo2(data);
            ultimo.setSig(nuevo);
            nuevo.setAnt(ultimo);
            ultimo = nuevo;
            ++size;
            return true;
        }
           
    }
    
    public String toString(){
        String Lista = "";
       if(size>0){
            Nodo2 aux = cabeza;
            for (int i = 0; i < size; i++) {
                Lista += aux.getDato()+" ";
                aux = aux.getSig();
            }
            return Lista;
        }else{
            throw new IndexOutOfBoundsException("Lista Vacia");
        } 
    }
    
    public int indexOf(int data){
        if(0 == size){
            return  -1;
        }else{
            Nodo2 aux = cabeza;
            int cont = 0;
            while (aux.getSig() != null && cont < size){
                if(aux.getDato() == data){
                    break;
                }else if (cont > size && aux.getDato() != data){
                    throw new IndexOutOfBoundsException("No existe");
//                    cont = -1;
                }else{
                    aux = aux.getSig();
                    ++cont;

                }
            }
            return cont;
        }
    }
    
    public boolean remove(int index) {
        if (index >= 0 && index <= size-1) {
            
            if (0 == index) {
                cabeza = cabeza.getSig();
                
            } else if (size-1 == index) {
                Nodo2 aux = ultimo;
                aux = aux.getAnt();
                aux.setSig(null);
                ultimo = aux;
                } else {
                int cont = 0;
                
                Nodo2 aux = cabeza;
                
                while (cont < index -1) {
                    aux = aux.getSig();
                    ++cont;
                }
                
                aux.setSig(aux.getSig().getSig());
                aux.getSig().setAnt(aux);
            }
            --size;
            return true;
        } else {
            throw new IndexOutOfBoundsException();
        }
    }
    
    public boolean removeObj(int data) {
        if (0 == size) {
            return false;
        } else {
            if (cabeza.getDato() == data) {
                Nodo2 aux = cabeza;
                aux = aux.getSig();
                aux.setAnt(null);
                cabeza = aux;
                ultimo.setSig(cabeza);
                cabeza.setAnt(ultimo);
                --size;
                return true;
            } else if (ultimo.getDato() == data) {
                Nodo2 aux = ultimo;
                aux = aux.getAnt();
                aux.setSig(null);
                ultimo = aux;
                ultimo.setSig(cabeza);
                cabeza.setAnt(ultimo);
                --size;
                return true;
            } else {
                int cont = 0;
                Nodo2 aux = cabeza;
                while (aux.getSig() != null && cont < size) {
                    if (aux.getDato() == data) {
                        aux.getAnt().setSig(aux.getSig());
                        aux.getSig().setAnt(aux.getAnt());
                        --size;
                        break;
                    }
                    aux = aux.getSig();
                    cont++;
                }
            }

            return true;
        }

    }
    
    public boolean AddSorted(int data){
        
        if (cabeza == null && ultimo == null) {
            Nodo2 nuevo = new Nodo2(data);
            cabeza = nuevo;
            ultimo = nuevo;
            ++size;
            return true;
        } else {      
            if(data < cabeza.getDato()){
                Nodo2 nuevo = new Nodo2(data);
                nuevo.setSig(cabeza);
                cabeza = nuevo;
                ++size;
                return true;
            }else{
                if(data > ultimo.getDato()){
                    Nodo2 nuevo = new Nodo2(data);
                    ultimo.setSig(nuevo);
                    nuevo.setAnt(ultimo);
                    ultimo = nuevo;
                    ++size;
                    return true;
                }else{
                    int cont = 0;
                    Nodo2 aux = cabeza;
                    Nodo2 nuevo = new Nodo2(data);
                    while (aux.getSig() != null && cont < size) {
                        if(data <= aux.getSig().getDato()){ 
                            nuevo.setSig(aux.getSig());
                            nuevo.setAnt(aux.getSig().getAnt());
                            aux.getSig().getAnt().setSig(nuevo);
                            aux.getSig().setAnt(nuevo);
                            size++;
                           break;
                        }
                        aux = aux.getSig();
                        cont++;
                    }
                    return true;
                }    
            }
       
        }
    }
    
    public void insertAtPos(int val , int index){

        Nodo2 nptr = new Nodo2(val);    

        if (index == 1)

        {

            addFirst(val);

            return;

        }            

        Nodo2 ptr = cabeza;

        for (int i = 1; i <= size; i++)

        {

            if (index == size()-1)

            {

                Nodo2 tmp = ptr.getSig();

                ptr.setSig(nptr);

                nptr.setAnt(ptr);

                nptr.setSig(tmp);

                tmp.setAnt(nptr);

            }

            ptr = ptr.getSig();            

        }
        if(index > size()-1){
            add(val);
        }



    }
        
     
}

    