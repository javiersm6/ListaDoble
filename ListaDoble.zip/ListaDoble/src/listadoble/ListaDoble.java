/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadoble;

import collection.Lista2;

/**
 *
 * @author Javier
 */
public class ListaDoble {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Lista2 miLista = new Lista2();
        miLista.add(1);
        miLista.add(2);
        miLista.add(3);
        miLista.add(4);
        
        miLista.add(14);
        
        miLista.remove(3);
        
        
        for (int i = 0; i < miLista.getSize(); i++) {
            System.out.println(miLista.get(i));
        }
        
//        System.out.println(miLista.toString());
        
    
}

}

